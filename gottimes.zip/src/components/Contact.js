import React from 'react';

const Contact = props => {
	// setTimeout(() => {
	// 	props.history.push('/about');
	// }, 2000);
	return (
		<div className="container">
			<h4 className="center">Contact</h4>
			<p>
				Lorem ipsum dolor, sit amet consectetur adipisicing elit. Illum delectus dolores, enim pariatur ab eius
				laudantium quidem totam exercitationem voluptatum quia quibusdam quis molestias ullam cumque eum itaque
				ex quos!
			</p>
		</div>
	);
};

export default Contact;
