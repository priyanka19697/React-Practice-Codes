const initState = {
	posts: [
		{ id: '1', title: 'hello there', body: 'Good Morning' },
		{ id: '2', title: 'I am  there', body: 'When will you reach' },
		{ id: '3', title: 'hello Bud', body: 'What are you upto this Morning' },
	],
};
const rootReducer = (state = initState, action) => {
	if (action.type === 'DELETE_POST') {
		let newPosts = state.posts.filter(post => {
			return action.id !== post.id;
		});
		return {
			...state,
			posts: newPosts,
		};
	}
	return state;
};

export default rootReducer;
